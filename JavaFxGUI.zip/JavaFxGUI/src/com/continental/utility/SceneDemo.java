package com.continental.utility;

import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class SceneDemo extends Application{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		//Creating a line object 
	      Line line = new Line(); 
	         
	      //Setting the properties to a line 
	      line.setStartX(0.0); 
	      line.setStartY(100.0); 
	      line.setEndX(400.0); 
	      line.setEndY(100.0); 
	      //create text
	    //Creating a Text object 
	      Text text = new Text(); 
	       
	      //Setting font to the text 
	      //Setting font to the text 
	      text.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));
	       
	      //setting the position of the text 
	      text.setX(20); 
	      text.setY(80);          
	      
	      //Setting the text to be added. 
	      text.setText("Welcome to JAVA FX Coding...");
	      
		Group group =new Group(line);
		//Retrieving the observable list object 
	      ObservableList list = group.getChildren(); 
	       
	      //Setting the text object as a node to the group object 
	      list.add(text);       
		Scene scene =new Scene(group,400,400);
		scene.setFill(Color.LIGHTBLUE);
		primaryStage.setTitle("Scene Creation...");
		primaryStage.setScene(scene);
		primaryStage.show();
		
	}

}
