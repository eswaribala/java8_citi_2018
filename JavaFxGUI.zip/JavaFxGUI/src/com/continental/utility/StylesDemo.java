package com.continental.utility;



import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class StylesDemo extends Application{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
           launch(args);
	}

	@Override
	public void start(Stage stage) throws Exception {
		// TODO Auto-generated method stub
		//creating label email 
	      Text text1 = new Text("Email");       
	      
	      //creating label password 
	      Text text2 = new Text("Password"); 
	       
	      //Creating Text Filed for email        
	      TextField textField1 = new TextField();       
	      
	      //Creating Text Filed for password        
	      PasswordField textField2 = new PasswordField();  
	       
	      //Creating Buttons 
	      Button button1 = new Button("Submit"); 
	      Button button2 = new Button("Clear");  
	      
	      //Creating a Grid Pane 
	      GridPane gridPane = new GridPane();    
	      
	      //Setting size for the pane 
	      gridPane.setMinSize(400, 200);
	      
	      //Setting the padding  
	      gridPane.setPadding(new Insets(10, 10, 10, 10)); 
	      
	      //Setting the vertical and horizontal gaps between the columns 
	      gridPane.setVgap(5); 
	      gridPane.setHgap(5);       
	      
	      //Setting the Grid alignment 
	      gridPane.setAlignment(Pos.CENTER); 
	       
	      //Arranging all the nodes in the grid 
	      gridPane.add(text1, 0, 0); 
	      gridPane.add(textField1, 1, 0); 
	      gridPane.add(text2, 0, 1);       
	      gridPane.add(textField2, 1, 1); 
	      gridPane.add(button1, 0, 2); 
	      gridPane.add(button2, 1, 2); 
	       
	      //Styling nodes  
	      button1.setStyle("-fx-background-color: darkslateblue; -fx-text-fill: white;"); 
	      button2.setStyle("-fx-background-color: darkslateblue; -fx-text-fill: white;"); 
	       
	      text1.setStyle("-fx-font: normal bold 20px 'serif' "); 
	      text2.setStyle("-fx-font: normal bold 20px 'serif' ");  
	      gridPane.setStyle("-fx-background-color: BEIGE;"); 
	      //Creating the mouse event handler 
	      EventHandler<MouseEvent> eventHandler = new EventHandler<MouseEvent>() { 
	         @Override 
	         public void handle(MouseEvent e) { 
	          //  System.out.println("My Skin color changed"); 
	        if ((textField1.getText().length()>0)	&&(textField2.getText().length()>0))
	        {
	            Alert alert = new Alert(AlertType.INFORMATION);
	            alert.setTitle("Login Information");
	            alert.setHeaderText("Information Alert");
	            String s ="Received credentials... ";
	            alert.setContentText(s);
	            alert.show();
	        }
	         } 
	      };  
	      //Registering the event filter 
	      button1.addEventFilter(MouseEvent.MOUSE_CLICKED, eventHandler);   
	       
	      // Creating a scene object 
	      Scene scene = new Scene(gridPane); 
	       
	      // Setting title to the Stage   
	      stage.setTitle("CSS Example"); 
	         
	      // Adding scene to the stage 
	      stage.setScene(scene);
	      
	      //Displaying the contents of the stage 
	      stage.show(); 
	}

}
