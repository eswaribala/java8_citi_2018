package com.cts.readwritelocks;

public class Reader implements Runnable{
private BookInfo bookinfo;
public Reader(BookInfo info)
{
	this.bookinfo=info;
}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=0;i<5;i++)
		{
			bookinfo.getPrice1();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			bookinfo.getPrice2();
		}
	}

}
