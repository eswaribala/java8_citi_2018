package com.cts.readwritelocks;

import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class BookInfo {
private int price1;
private int price2;
private ReadWriteLock lock;
public BookInfo()
{
	price1=0;
	price2=0;
	lock=new ReentrantReadWriteLock();
}
public int getPrice1() {
	lock.readLock().lock();
	double val=price1;
	System.out.println("Book Price Price1 read as= "+val);
	
	lock.readLock().unlock();
	return price1;
}
public int getPrice2() {
	lock.readLock().lock();
	double val=price2;
	System.out.println("Book Price Price2 read as= "+val);
	
	lock.readLock().unlock();
	return price2;
}

public void setPrice(int f1,int f2)
{
	lock.writeLock().lock();
	price1=f1;
	price2=f2;
	System.out.println("price modeified");
	lock.writeLock().unlock();
}


}
