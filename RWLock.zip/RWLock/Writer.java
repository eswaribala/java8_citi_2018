package com.cts.readwritelocks;

public class Writer implements Runnable{
	private BookInfo bookinfo;
	public Writer(BookInfo info)
	{
		this.bookinfo=info;
	}
		@Override
		public void run() {
			// TODO Auto-generated method stub
			for(int i=0;i<5;i++)
			{
				bookinfo.setPrice(i*100,i*100+100);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		}

}
