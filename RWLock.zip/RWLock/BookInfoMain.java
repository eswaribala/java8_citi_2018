package com.cts.readwritelocks;

public class BookInfoMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
          BookInfo bookinfo =new BookInfo();
          Reader[] reader =new Reader[5];
          Thread[] readerThread=new Thread[5];
          
         
          for(int i=0;i<5;i++)
          {
        	  reader[i]=new Reader(bookinfo);
        	  readerThread[i]=new Thread(reader[i]);
          }
          
        	Writer writer =new Writer(bookinfo);
        	  Thread writerThread=new Thread(writer);
        	  for(int i=0;i<5;i++)
              { 
        		  readerThread[i].start();
              }
        	  writerThread.start();
	}

}
